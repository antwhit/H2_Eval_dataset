class TestParser {

    private static SimpleCharStream instream;

    private static ParserTokenManager scanner;

    private static Parser parser;

    public static void main(String args[]) {
        java.io.InputStream infile;
        if (args.length < 1) {
            infile = System.in;
        } else try {
            infile = new java.io.FileInputStream(args[0]);
        } catch (java.io.FileNotFoundException e) {
            System.out.println("File " + args[0] + " not found.");
            return;
        }
        instream = new SimpleCharStream(infile);
        scanner = new ParserTokenManager(instream);
        parser = new Parser(scanner);
        while (nextParseSkipErrors()) ;
    }

    private static boolean nextParseSkipErrors() {
        SimpleNode tree;
        try {
            tree = parser.start();
            tree.dump("");
            System.out.println();
        } catch (TokenMgrError e) {
            System.out.println(e.toString());
            return false;
        } catch (ParseException e) {
            if (e.currentToken.next.kind != ParserConstants.EOF) System.out.println(e.toString());
            return false;
        }
        return true;
    }
}
