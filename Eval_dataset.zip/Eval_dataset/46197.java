/**
 * @author Thomas Muenz
 *
 */
public class Superclass {

    @SuppressWarnings("unused")
    private int value;

    private SubClass sc = new SubClass();

    {
        ((Superclass) sc).value = 0;
    }

    private static class SubClass extends Superclass {
    }
}
