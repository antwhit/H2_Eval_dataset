import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class Listing1804_02 {

    public static void main(String args[]) {
        PrintWriter writer;
        long nenner = 0;
        double summe = 0.0;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter("/tmp/zwei.txt")), true);
            for (nenner = 1; nenner <= 1024 * 1024 * 1024; nenner *= 2) {
                summe += 1.0 / nenner;
                writer.print("Summand: 1/");
                writer.print(nenner);
                writer.print("\t\tSumme: ");
                writer.println(summe);
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Can not open file");
        }
    }
}
