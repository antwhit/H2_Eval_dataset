public class A {

    public static void main(String[] args) {
        A a = new A();
        a.beMoreFunny();
    }

    public void beMoreFunny() {
        System.out.println("woosle wassle!");
    }
}
