public class StorageRoom extends Storage {

    public int storeStones(int x) {
        stones += x;
        return x;
    }

    public int storeWood(int x) {
        wood += x;
        return x;
    }

    public int storeCrops(int x) {
        crops += x;
        return x;
    }

    public int storeBerries(int x) {
        berries += x;
        return x;
    }

    public int storeMushrooms(int x) {
        mushrooms += x;
        return x;
    }

    public int storeWater(int x) {
        water += x;
        return x;
    }

    public int storeTools(int x) {
        tools += x;
        return x;
    }

    public int storeWeapons(int x) {
        weapons += x;
        return x;
    }

    public int storeDeadGame(int x) {
        deadGame += x;
        return x;
    }

    public int storeCattle(int x) {
        cattle += x;
        return x;
    }

    public int storeDeadCattle(int x) {
        deadCattle += x;
        return x;
    }

    public int storeBread(int x) {
        bread += x;
        return x;
    }

    public int storeMeat(int x) {
        meat += x;
        return x;
    }

    public int storeClothes(int x) {
        clothes += x;
        return x;
    }
}
