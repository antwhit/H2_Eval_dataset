import java.io.FileWriter;
import java.io.IOException;

/**
 * Classe FormatCSVCroisementEcrire<br/>
 * <b>FormatCSVCroisementEcrire permet d'enregistrer dans un fichier csv un croisement</b>
 * <p>
 * Cette classe est compos�e d'un constructeur par d�faut et d'une unique m�thode static 
 * qui permet d'enregistrer un croisement donn� dans un fichier csv sp�cifique.
 * @see EcrireCSV
 * 
 * @author groupe 2
 * @version 1.0
 *</p>
 */
public class FormatCSVCroisementEcrire {

    /**
		 * Constructeur de FormatCSVCroisementEcrire<br/>
		 * <p>
		 * Constructeur sans param�tre, il cr�e uniquement un espace m�moire.
		 * </p>
		 */
    public FormatCSVCroisementEcrire() {
    }

    /**
	 * ecrireInfo(Croisement, FileWriter) permet d'enregistrer un croisement dans un fichier 
	 * pour le garder en m�moire. 
	 * @param croisement, le croisement � noter
	 * @param fwt, le flux d'�criture de texte, soit un pointeur vers le fichier m�moire.
	 * @throws IOException, si le flux n'est pas correct.
	 */
    public static void ecrireInfo(Croisement croisement, FileWriter fwt) throws IOException {
        fwt.write(croisement.toString());
    }
}
