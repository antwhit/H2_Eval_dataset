class DeprecatedFilename {

    DeprecatedClass d;
}

class DeprecatedFilenameAdditional {

    DeprecatedClass d;
}

@Deprecated
class DeprecatedClass {
}
