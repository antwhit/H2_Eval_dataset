import sketch.ounit.Observer;
import sketch.ounit.Values;
import sketch.specs.annotation.TestSketch;
import treemap.TreeMap;
import junit.framework.TestCase;
import packageName.TestGeneratedForIntegratingRandom;
import gov.nasa.jpf.symbc.Debug;

public class TestGeneratedForIntegratingRandom_testRemoveTreeMap462 {

    public static void main(String[] args) {
        TestGeneratedForIntegratingRandom c = new TestGeneratedForIntegratingRandom();
        c.testRemoveTreeMap462();
        Debug.getSolvedPC();
    }
}
