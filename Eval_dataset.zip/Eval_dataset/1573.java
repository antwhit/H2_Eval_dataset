import com.dinim.matrix.twodimensional.Vector3;

public abstract class Feature {

    public abstract VoronoiRegion getVoronoiRegion();
}
