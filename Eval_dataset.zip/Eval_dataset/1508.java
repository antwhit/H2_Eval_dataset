class T852nsmu2 {

    void foo() {
    }

    static class T852nsmu2_Test {

        T852nsmu2_Test() {
            foo();
        }
    }
}
