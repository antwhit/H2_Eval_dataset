import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorPantallaAltaSandwich implements ActionListener {

    public ControladorPantallaAltaSandwich(PantallaAltaSandwich pantallaAltaSandwich, AplicacionEmpleado aplicacionEmpleado) {
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
