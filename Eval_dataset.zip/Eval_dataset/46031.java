class Search {

    int search(int[] a, int x) {
        int result = -1;
        int left = 0;
        while (result == -1 && left < a.length) {
            if (a[left] == x) {
                result = left;
            } else {
                left = left + 1;
            }
        }
        return result;
    }
}
