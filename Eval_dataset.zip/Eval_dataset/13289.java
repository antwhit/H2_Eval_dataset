import java.net.InetAddress;
import edu.ucla.cs.typecast.net.NetUtil;
import edu.ucla.cs.typecast.rmi.TypeCastClient;
import edu.ucla.cs.typecast.scope.HostScope;
import edu.ucla.cs.typecast.scope.TTLScope;

public class Ping2Client {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            TypeCastClient client = new TypeCastClient();
            Options options = new Options(args);
            String host = options.getOption("-host");
            if (host != null) {
                HostScope hostScope = new HostScope(InetAddress.getByName(host));
                client.setScope(hostScope);
            }
            String ttl = options.getOption("-ttl");
            if (ttl != null) {
                TTLScope ttlScope = new TTLScope(Integer.parseInt(ttl));
                client.setScope(ttlScope);
            }
            Ping2Service ping2Service = client.getInvocationHandler(Ping2Service.class);
            ping2Service.ping(NetUtil.getLocalHost(), options.getParameter(0));
            ping2Service.ping2(NetUtil.getLocalHost(), options.getParameter(1));
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
