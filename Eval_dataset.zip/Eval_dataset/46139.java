public class T1420try32 {

    public static void main(String[] args) {
        try {
            new Object();
        } finally {
            return;
        }
        {
        }
    }
}
