class Base {

    void m(Object... x) {
    }
}

class OverrideVarargsExtra extends Base {

    void m(Object[] x) {
    }
}
