public class AnnounceWrongReturnType{
	
	//announce doesn't return and should.
	public Object foo1(){
		announce Nonvoid(){}
		return new Object();
	}
	
	//announce returns and shouldn't
	public void foo2(){
		announce Event1(){return new Object();}
	}
	
	//announce returns wrong type
	public java.util.ArrayList foo3(){
		announce Nonvoid(){return new Object();}
	}
}