public class Boxing4 {

    public static void main(String[] args) {
        Character ch = 95;
        ch++;
        System.out.println(ch + 0);
    }
}
