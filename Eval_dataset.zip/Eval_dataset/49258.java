import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import utility.Input;

/**
 *
 * @author wiki22
 * @version
 * This servlet accepts request for page updation. Sets object in session and redirects request
 * to Edit.html page for updation.
 */
public class PageEditorServlet extends HttpServlet {

    /**
	 * 
	 */
    private static final long serialVersionUID = -7397120875326650449L;

    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String RequestURI = request.getRequestURI();
            response.sendRedirect("/poolweb/Edit/examples/EditJsp.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
