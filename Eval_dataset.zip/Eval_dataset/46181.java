import java.awt.*;

public class LogicXor extends Logic {

    LogicXor() {
        super.name = "[logic] XOR Gate";
    }

    public void init(Project parent, String data) {
        this.parent = parent;
        super.gate = Toolkit.getDefaultToolkit().getImage("images/logic_xor.gif");
        super.init(parent, data);
    }

    public void ioChangeNotify() {
        boolean result = input.state[0] ^ input.state[1];
        boolean old_value = input.state[2];
        if (result) input.state[2] = true; else input.state[2] = false;
        if (result != old_value) {
            parent.postPinUpdate(this);
        }
        repaint();
    }
}
