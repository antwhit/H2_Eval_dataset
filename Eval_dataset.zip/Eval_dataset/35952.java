public class T1615daf12 {

    public static void main(String[] args) {
        boolean a = true, x;
        if (a ? true : true) ;
        a = x;
    }
}
