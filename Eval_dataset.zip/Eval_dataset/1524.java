public class Set extends Collection {

    public Object[] values;

    public int size() {
        return values.length;
    }
}
