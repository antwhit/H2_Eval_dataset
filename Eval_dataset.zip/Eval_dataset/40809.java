import java.lang.Thread;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class EzimAckSender extends Thread {

    private EzimMain emHwnd;

    private String msg;

    public EzimAckSender(EzimMain emIn, String strIn) {
        this.emHwnd = emIn;
        this.msg = strIn;
    }

    public void run() {
        MulticastSocket ms = null;
        InetAddress ia = null;
        DatagramPacket dp = null;
        byte[] arrBytes = null;
        try {
            ia = InetAddress.getByName(Ezim.mcGroup);
            ms = new MulticastSocket(Ezim.ackPort);
            ms.setReuseAddress(true);
            ms.setTimeToLive(Ezim.ttl);
            if (ms.getLoopbackMode()) ms.setLoopbackMode(false);
            arrBytes = this.msg.getBytes(Ezim.rtxEnc);
            dp = new DatagramPacket(arrBytes, arrBytes.length, ia, Ezim.ackPort);
            ms.send(dp);
        } catch (Exception e) {
            emHwnd.errAlert(e.getMessage());
        } finally {
            try {
                if (ms != null && !ms.isClosed()) ms.close();
            } catch (Exception e) {
            }
        }
        return;
    }
}
