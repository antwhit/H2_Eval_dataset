public class Test53 {

    public Test53(String name, Object o, String[] array) {
        this(name, o, (String) null, array);
    }

    public Test53(String name, Object o, String dummy, String[] array) {
    }
}
