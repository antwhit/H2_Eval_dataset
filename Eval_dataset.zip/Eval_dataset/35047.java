import javax.swing.JDialog;

public class PantallaMantenimientoTipoSandwich extends JDialog {

    public PantallaMantenimientoTipoSandwich(AplicacionEmpleado ae) {
    }
}
